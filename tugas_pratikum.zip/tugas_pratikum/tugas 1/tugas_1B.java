package tugas_pratikum;

import java.util.Scanner;

public class tugas_1B {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int pilihan;
        System.out.println("=== Program Deret Fibonacci ===");
        System.out.println("1. Deret Fibonacci dari 0 sampai 100");
        System.out.println("2. Deret Fibonacci dengan batas bawah dan batas atas");
        System.out.print("Pilih program (1/2): ");
        pilihan = input.nextInt();
    }
    
}
