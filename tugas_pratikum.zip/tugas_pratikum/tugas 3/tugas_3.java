package tugas_pratikum ;
import java.util.Scanner;
import java.util.LinkedList;
import java.util.Queue;
public class tugas_3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Queue<Integer>antrian= LinkedList(System.in);
        final int MAX_ANTRIAN = 10;

        System.out.print("Masukkan jumlah pasien yang datang: ");
        int jumlahPasien = input.nextInt();

        int pasienDilayani = 0;

        for (int i = 1; i <= jumlahPasien; i++) {
            if (antrian.size() < MAX_ANTRIAN) {
                antrian.add(i);
                System.out.println("Pasien " + i + " masuk ke antrian. (Jumlah antrian: " + antrian.size() + ")");
            } else {
                System.out.println("Antrian penuh! Pasien " + i + " menunggu...");
                // Simulasi: pasien pertama selesai dilayani
                int pasienKeluar = antrian.poll();
                pasienDilayani++;
                System.out.println("Pasien " + pasienKeluar + " selesai dilayani dan keluar dari antrian.");
                antrian.add(i);
                System.out.println("Pasien " + i + " sekarang masuk ke antrian. (Jumlah antrian: " + antrian.size() + ")");
            }
        }

        System.out.println("\n=== Semua pasien sudah datang ===");
        System.out.println("Sisa pasien dalam antrian: " + antrian);
        System.out.println("Total pasien dilayani: " + pasienDilayani);
        input.close();
    }
}

